package edu.vtc.cis2271;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.WindowListener;


/** GUI Programming
 * Layout
 * Behavior
 * Package Javax.swing  contains jComponents
 * Border Layout on JFrame
 * Box Layout horizontal = x axis, vert y axis
 * strut = fixed size - like max height
 * glue = expand to fill all space - magins
 * pack = build the layout
 * check JFileDialog - check JavaDoc
 *
 */

public class Classwork1013 {
    public static void main(String[] args) {
        new JButton("Click me");
        new JFrame();
        Guiable.window= new Guiable("Test Window");
        window.setVisible(true);
    }
}

public class Guiable extends JFrame implements WindowListener
{
    super(title);
    setLayout(new BorderLayout());
    JTextArea text = new JTextArea(20,50); //horiz, vert
    add(BorderLayout.CENTER,text);
    Box buttons = new Box(BoxLayout.X_AXIS);
    JButton hello = new JButton("Hello");
    buttons.add(Box.createHorizontalStrut(30));
    text.setText("this is sample text.  Let's see what it looks like.");
    pack();
    addWindowListener(this);
    JButton goodbye=new JButton("Goodbye");
    buttons.add(goodbye);
    .addsActionListener((ActionEvent e)->text.setText("Good riddance"));

    yes.addActionListerner((e)->System.out.printlin("We are positive!"));
    yes.addActionListener(new ActionListener()
}

private static class HelloBehavior implements ActionListener
{
    public HelloBehavior(JTextArea text)
    {
        _text=text;
    }
}

public void goodbye(){
    System.exit(0);
}

public void windowClosing(WindowEvent e) {
    System.exit(0);
}
