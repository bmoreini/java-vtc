package edu.vtc.cis2271;

import java.util.ArrayList;

/**
 * Letter from Homework 3 P8.9
 *
 * @author Bram Moreinis
 *

 * Also supply a main method that prints this letter.
 * Dear John:
 *
 * I am sorry we must part.
 * I wish you all the best.
 *
 * Sincerely,
 *
 * Mary
 * Construct an object of the Letter class and call addLine twice.
 */

public class Letter {

    public Letter(String from, String to) {
        _from = from;
        _to = to;
        _lastLine = 2;
        _Lines = new ArrayList<String>();
        _Lines.add(0, ("Dear "+to+","));
        _Lines.add(1, (""));
        _Lines.add(2, (""));
        _Lines.add(3, ("Sincerely,"));
        _Lines.add(4, (""));
        _Lines.add(5, (from));

    }

    public void addLine(String line) {

        _Lines.add(_lastLine, line);
        setLastLine(_lastLine++);
    }

    public void printLetter()
    {
        for (int i = 0; i < _Lines.size(); i++)
        {
            String line = _Lines.get(i);
            System.out.println(line);
        }
    }

    public void setLastLine(int _lastLine) {
        this._lastLine = _lastLine;
    }

    private String _from;
    private ArrayList<String> _Lines;
    private String _to;
    private int _lastLine;

    public static void main(String[] args) {
        Letter dearJohn = new Letter("Mary", "John");
        dearJohn.addLine("I am sorry we must part.");
        dearJohn.addLine("I wish you all the best.");
        dearJohn.printLetter();
        }
    }




