package edu.vtc.cis2271;


import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;

public class DrawMe extends JPanel {
    public DrawMe()
    {
        setMinimumSize(new Dimension(500,300));
        setPreferredSize(new Dimension(500,300));
        setBorder(new LineBorder(Color.BLUE,10));
        setBackground(Color.LIGHT_GRAY);

    }

    @Override
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);

    }
}