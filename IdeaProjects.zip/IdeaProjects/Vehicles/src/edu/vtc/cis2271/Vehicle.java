package edu.vtc.cis2271;

public class Vehicle
{
    private int numberOfTires;

    public int getNumberOfTires()
    {
        return numberOfTires;
    }

    public void setNumberOfTires(int newValue)
    {
        numberOfTires = newValue;
    }

    public String getDescription()
    {
        return "A vehicle with " + numberOfTires + " tires";
    }

    public String toString()
    {
        return getClass().getName() + "[numberOfTires=" + numberOfTires + "]";
        // This is a good way of implementing toString in a superclass--see Special Topic 9.6
    }
}
