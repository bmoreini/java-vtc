package edu.vtc.cis2271;

public class Sedan extends Car {
    public Sedan(int mileage, int numPassengers) {
        super(mileage);
        super(numPassengers);
    }
}
