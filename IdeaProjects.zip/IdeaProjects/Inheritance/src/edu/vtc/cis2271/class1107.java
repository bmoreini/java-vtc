package edu.vtc.cis2271;

import java.io.*;
import java.util.Arrays;
import java.util.Scanner;

public class class1107 {
    public static void main(String[] args)
                throws Exception
        {
            Scanner in = new Scanner(new File("x.txt"));
            PrintStream out = new PrintStream("y.txt");
            for (int n = 0; in.hasNextLine(); n++)
            {
                String l = in.nextLine();
                out.println(n+": "+l.charAt(0)+
                        " "+l.length());
            }
            out.close();
            in.close();
        }

        /* Inheritance */


    }
