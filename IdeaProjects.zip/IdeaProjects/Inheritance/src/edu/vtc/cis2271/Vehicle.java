package edu.vtc.cis2271;

public class Vehicle {

    public Vehicle (int mileage){
        _mileage=mileage;
    }

    public void drive () {
    }

    private int _mileage;

    public int getMileage() {
        return _mileage;
    }
}
