package edu.vtc.cis2271;

// abstract means can't say "new shape"

import java.util.ArrayList;
import java.util.List;

public abstract class Shape {  // extends Object

    public abstract double getArea(); // no codeblock because can't compute

    public abstract double getCirc();

    public static void main(String[] args) {
        List<Shape> Shapes = new ArrayList<>();
        double totalCirc = 100;
    }

 }


