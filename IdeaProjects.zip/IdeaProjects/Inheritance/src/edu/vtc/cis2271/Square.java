package edu.vtc.cis2271;

import java.util.ArrayList;
import java.util.List;

public class Square extends Shape {

    public Square (double side) {
        _side = side;
    }

    public double getArea() {
        return _side * _side;
    }

    public double getCirc() {
        return 4 * _side;
    }

    private double _side;

    public String toString() {
        return "Square with side = "+_side;
    }

    public static void main(String[] args) {
        Object o = new Square(9);
        System.out.print(o);
    }

    // overriding only applies to non-static methods
}