package edu.vtc.cis2271;

import java.awt.print.Book;
import java.io.IOException;
import java.util.Collection;
import java.util.Optional;

public class BookCollection {

// standard approach
    /* int totalPages=0;
    public static void main(String[] args)  {
       for (Book b: library) {
           if (b.myRating() <3) {
               continue;
           }
           totalPages += b.getPageCount();
        for (Author a: faves) {

       }
    }*/

// stream-processing approach
// library is a collection of book
     Collection<Author> faves {};
     Collection<Book> library {};


int totalPages = library.stream()
        .filter(b->b.myRating() >= 3) // takes in value, returns boolean. lambda function
        .unique()
        .mapToInt(b->b.getPageNumber()) // give me a stream of pagecounts
        .map(b->b.getAuthor().b.getName())
        .sum();  // defined by int stream

int howmanyBooks = faves.stream()
        .map (a->a.getBooks().stream())
        .flatMap()
        .unique()
        .mapToInt(b->b.getPageCount())
        .count();
}

Optional<Book> obook;
     obook.get();
     .forEach(System.out.println(b))


// Filter takes a predicate, returns boolean
// Map converts stream to stream of something else
// Sort sorts as you go
// Unique throw away dupes

