/**
 * Guiable.java
 * Copyright 2015, Craig A. Damon
 * all rights reserved
 */
package edu.vtc.cis2271;

import java.awt.BorderLayout;
import java.awt.GraphicsConfiguration;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;

/**
 * Guiable - description
 * @author Craig A. Damon
 *
 */
public class Guiable extends JFrame implements WindowListener
{

	/**
	 * @param title
	 * @throws HeadlessException
	 */
	public Guiable(String title) throws HeadlessException
	{
	super(title);
	setLayout(new BorderLayout());
	
  JTextArea text = new JTextArea(20,50);
//  add(BorderLayout.CENTER,text);
  DrawMe draw = new DrawMe();
  add(BorderLayout.CENTER,draw);

	Box buttons = new Box(BoxLayout.X_AXIS);
	
  JButton hello = new JButton("Hello");
  buttons.add(Box.createHorizontalStrut(30));
	buttons.add(Box.createGlue());
  buttons.add(hello);
	buttons.add(Box.createGlue());
	hello.addActionListener(new HelloBehavior(text));
	
	JButton goodbye = new JButton("Goodbye");
	buttons.add(goodbye);
	buttons.add(Box.createGlue());
	goodbye.addActionListener((e)->text.setText("Good riddance") );
	
	JButton quit = new JButton("Quit");
	buttons.add(quit);
	quit.addActionListener((e)->goodbye());
	
	buttons.add(Box.createGlue());
  buttons.add(Box.createHorizontalStrut(30));
  add(BorderLayout.SOUTH,buttons);
  
  add(BorderLayout.NORTH,new JLabel("This is a label"));
  
  Box radios = new Box(BoxLayout.Y_AXIS);
  add(BorderLayout.EAST,radios);
  JRadioButton yes = new JRadioButton("yes");
  JRadioButton no = new JRadioButton("no");
  JRadioButton maybe = new JRadioButton("maybe");
  radios.add(yes);
  radios.add(no);
  radios.add(maybe);
  radios.add(Box.createVerticalStrut(30));
  ButtonGroup yesNo = new ButtonGroup();
  yesNo.add(yes);
  yesNo.add(no);
  yesNo.add(maybe);
  yes.addActionListener((e)->System.out.println("We are positive today!"));
  
  yes.addActionListener(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e)
		{
			System.out.println("We are here!");
			
		}
  	
  });
  JRadioButton it = new JRadioButton("IT");
  JRadioButton se = new JRadioButton("SE");
  JRadioButton cpe = new JRadioButton("CPE");
  radios.add(it);
  radios.add(se);
  radios.add(cpe);
  ButtonGroup major = new ButtonGroup();
  major.add(it);
  major.add(se);
  major.add(cpe);
  
  pack();
	addWindowListener(this);
	}
	
	public void goodbye()
	{
		System.exit(0);
	}
	
	
	public void sleep()
	{
		try
		{
		Thread.sleep(3000);
		}
	catch (InterruptedException e)
		{
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
	}

	
	public static void main(String[] args)
	{
		Guiable window = new Guiable("Test Window");
		window.setVisible(true);
	}

	private static class HelloBehavior implements ActionListener
	{
  public HelloBehavior(JTextArea text)
  {
  	  _text = text;
  }
	/**
	 * @param e
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent e)
	{
		_text.append("Hello\n");
		
	}
		private JTextArea _text;
	}

	/**
	 * @param e
	 * @see java.awt.event.WindowListener#windowOpened(java.awt.event.WindowEvent)
	 */
	@Override
	public void windowOpened(WindowEvent e)
	{
	// TODO Auto-generated method stub
	
	}


	/**
	 * @param e
	 * @see java.awt.event.WindowListener#windowClosing(java.awt.event.WindowEvent)
	 */
	@Override
	public void windowClosing(WindowEvent e)
	{
	   System.exit(0);
	}


	/**
	 * @param e
	 * @see java.awt.event.WindowListener#windowClosed(java.awt.event.WindowEvent)
	 */
	@Override
	public void windowClosed(WindowEvent e)
	{
	// TODO Auto-generated method stub
	
	}


	/**
	 * @param e
	 * @see java.awt.event.WindowListener#windowIconified(java.awt.event.WindowEvent)
	 */
	@Override
	public void windowIconified(WindowEvent e)
	{
	// TODO Auto-generated method stub
	
	}


	/**
	 * @param e
	 * @see java.awt.event.WindowListener#windowDeiconified(java.awt.event.WindowEvent)
	 */
	@Override
	public void windowDeiconified(WindowEvent e)
	{
	// TODO Auto-generated method stub
	
	}


	/**
	 * @param e
	 * @see java.awt.event.WindowListener#windowActivated(java.awt.event.WindowEvent)
	 */
	@Override
	public void windowActivated(WindowEvent e)
	{
	// TODO Auto-generated method stub
	
	}


	/**
	 * @param e
	 * @see java.awt.event.WindowListener#windowDeactivated(java.awt.event.WindowEvent)
	 */
	@Override
	public void windowDeactivated(WindowEvent e)
	{
	// TODO Auto-generated method stub
	
	}
}
