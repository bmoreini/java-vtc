package edu.vtc.cis2271;

import java.util.*;

public class StringLengths {
    public static void main(String[] args) {


    }
    public static double SL (Collection<String> myString) {
        Integer total=0;
        for (String myLine : myString) {
            total+=myLine.length();
        }
        return (double)total/myString.size();
    }
    public static List<String> myOdds(List<String> myString) {
        List<String> oddList = new ArrayList<>();
        for (String myLine : myString) {
            if ((myLine.length() % 2) == 1) ;
            oddList.add(myLine);
        }
        return oddList;
    }
    Set<String> Recipe = new HashSet<String>();
    private Map<Ingredient, Set<Recipe>> _ingredients;

    public Ingredient(String name)
    {
        _name = name;
    }

    public void addRecipe(Recipe r, Collection<Ingredient> _ingredients) {
        for (Ingredient i : _ingredients)
        {
           if (!_ingredients.containsKey(i))     {
               _ingredients.put(i, new HashSet<>());
           }
           Set<Recipe> recipes = _ingredients.get(i);
           recipes.add(r);
        }
    }
}
