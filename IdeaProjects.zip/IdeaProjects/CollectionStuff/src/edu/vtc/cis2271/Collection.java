package edu.vtc.cis2271;
import java.util.ArrayList;
import java.util.TreeSet;
import java.util.Collections;
import java.util.List;

public class Collection {

	public static void main(String[] args) {
		
		/** COLLECTIONS **/
		Collection<String> coll =     new ArrayList<String>();
		//The ArrayList class implements the Collection interface.
		coll = new TreeSet<String>(); 
		//The TreeSet class (Section 15.3) also implements the Collection interface. 
		// int n = coll.size(); 
		//Gets the size of the collection. n is now 0.
		coll.add("Harry"); 
		coll.add("Sally");
		//Adds elements to the collection. 
		String s = coll.toString(); 
		//Returns a string with all elements in the collection. s is now "[Harry, Sally]" 
		//System.out.println(coll); 
		//Invokes the toString method and prints [Harry, Sally].
		coll.remove("Harry"); 
		boolean b = coll.remove("Tom");
		//Removes an element from the collection, returning false if the element is not present. b is false. 
		b = coll.contains("Sally"); 
		//Checks whether this collection contains a given element. b is now true.
		for (String s : coll) {   
		System.out.println(s); 
		}
		//You can use the �for each� loop with any collection. This loop prints the elements on separate lines. 
		Iterator<String> iter = coll.iterator() 
		//You use an iterator for visiting the elements in the collection 
				
		/** LINKED LISTS **/
		
		LinkedList<String> list = new LinkedList<String>(); 
		//An empty list. 
		list.addLast("Harry"); 
		//Adds an element to the end of the list. Same as add. 
		list.addFirst("Sally"); 
		//Adds an element to the beginning of the list. list is now [Sally, Harry]. 
		list.getFirst(); 
		//Gets the element stored at the beginning of the list; here "Sally". 
		list.getLast(); 
		//Gets the element stored at the end of the list; here "Harry". 
		String removed = list.removeFirst(); 
		//Removes the first element of the list and returns it. removed is "Sally" and list is [Harry]. Use removeLast to remove the last element. 
		ListIterator<String> iter = list.listIterator() 
		//Provides an iterator for visiting all list elements (see Table 3 on page W676).

		if (iterator.hasNext()) 
		{   
			iterator.next(); 
		} 
	
		while (iterator.hasNext()) 
		{    
		String name = iterator.next();   
		//Do something with name 
		} 
		/** methods of the Iterator and ListIterator interfaces  **/
		
		String s = iter.next(); 
		//Assume that iter points to the beginning of the list [Sally] before calling next. After the call, s is "Sally" and the iterator points to the end. 
		iter.previous(); 
		iter.set("Juliet");

		//The set method updates the last element returned by next or previous. The list is now [Juliet]. iter.hasNext() 
		//Returns false because the iterator is at the end of the collection. 
		if (iter.hasPrevious()) {   
			s = iter.previous(); 
			}

		//hasPrevious returns true because the iterator is not at the beginning of the list. previous and hasPrevious are ListIterator methods.
		iter.add("Diana"); 
		//Adds an element before the iterator position (ListIterator only). The list is now [Diana, Juliet]. 
		iter.next(); iter.remove();

		//remove removes the last element returned by next or previous. The list is now [Diana].

	}

}
