package edu.vtc.cis2271;

import java.util.*;

public class MyArrayList {

    public static void main(String[] args) {
        /** LINKED LISTS **/

        LinkedList<String> list = new LinkedList<String>();
        //An empty list.
        list.addLast("Harry");
        //Adds an element to the end of the list. Same as add.
        list.addFirst("Sally");
        //Adds an element to the beginning of the list. list is now [Sally, Harry].
        list.getFirst();
        //Gets the element stored at the beginning of the list; here "Sally".
        list.getLast();
        //Gets the element stored at the end of the list; here "Harry".
        String removed = list.removeFirst();
        //Removes the first element of the list and returns it. removed is "Sally" and list is [Harry]. Use removeLast to remove the last element.
        if (iterator.hasNext())
        {
            iterator.next();
        }

        while (iterator.hasNext())
        {
            String name = iterator.next();
            //Do something with name
        }
        /** methods of the Iterator and ListIterator interfaces  **/

        String x = iterator.next();
        //Assume that iter points to the beginning of the list [Sally] before calling next. After the call, s is "Sally" and the iterator points to the end.
        iterator.previous();
        iterator.set("Juliet");

        //The set method updates the last element returned by next or previous. The list is now [Juliet]. iter.hasNext()
        //Returns false because the iterator is at the end of the collection.
        if (iterator.hasPrevious()) {
            s = iterator.previous();
        }

        //hasPrevious returns true because the iterator is not at the beginning of the list. previous and hasPrevious are ListIterator methods.
        iterator.add("Diana");
        //Adds an element before the iterator position (ListIterator only). The list is now [Diana, Juliet].
        iterator.next(); iterator.remove();

        //remove removes the last element returned by next or previous. The list is now [Diana].

    }

}
