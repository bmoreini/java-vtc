package edu.vtc.cis2271;

import java.util.*;

public class MyArrayList {

    public static void main(String[] args) {

        /** COLLECTIONS **/
        Collection<String> coll = new ArrayList<>();
        //The ArrayList class implements the Collection interface.
        coll = new TreeSet<String>();
        //The TreeSet class (Section 15.3) also implements the Collection interface.
        int n = coll.size();
        //Gets the size of the collection. n is now 0.
        coll.add("Harry");
        coll.add("Sally");
        //Adds elements to the collection.
        System.out.println(coll);
        //Invokes the toString method and prints [Harry, Sally].
        coll.remove("Harry");
        Boolean b = coll.remove("Tom");
        //Removes an element from the collection, returning false if the element is not present. b is false.
        b = coll.contains("Sally");
        //Checks whether this collection contains a given element. b is now true.
        String sx = coll.toString();
        //Returns a string with all elements in the collection. s is now "[Harry, Sally]"
        for (String x : coll) {
            System.out.println(x);
        }
        //You can use the �for each� loop with any collection. This loop prints the elements on separate lines.
    }

}
