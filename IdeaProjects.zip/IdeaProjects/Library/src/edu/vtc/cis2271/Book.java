/**
 * Book.java
 * Copyright 2015, Craig A. Damon
 * all rights reserved
 */
package edu.vtc.cis2271;

/**
 * Book - description
 * @author Craig A. Damon
 *
 */
public class Book
{
    /**
     * create a book
     * @param title the title, never null
     * @param author the author, never null
     * @param year the year written
     */
    public Book(String title, Author author,int year)
    {
        _title = title;
        _author = author;
        _year = year;
        author.addBook(this);
    }

    /**
     * Use the title as a human readable identifier for the book
     * @return the title
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString()
    {
        return _title;
    }

    /**
     * @return the title
     */
    public String getTitle()
    {
        return _title;
    }

    /**
     * @return the year
     */
    public int getYear()
    {
        return _year;
    }

    /**
     * @return the author
     */
    public Author getAuthor()
    {
        return _author;
    }

    /** test creating a single book
     * @param args
     */
    public static void main(String[] args)
    {
        Author a = new Author("Frank Herbert");
        Book b = new Book("Dune",a,1973);
        System.out.println(b);
    }


    private String _title;
    private int _year;
    private Author _author;
}
