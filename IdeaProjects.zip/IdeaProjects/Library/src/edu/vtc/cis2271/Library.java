/**
 * Collies.java
 * Copyright 2016, Craig A. Damon
 * all rights reserved
 */
package edu.vtc.cis2271;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Collies - work on the collection worksheet
 * @author Craig A. Damon
 *
 */
public class Library
{

    public Library()
    {
        _authors = new ArrayList<>();
    }

    public void addAuthor(Book b,Collection<Author> authors)
    {
        for (Author a : authors)
        {
            if (!_authors.containsKey(a))
            {
                // a new Author to me, set up the set of Books for it
                _authors.put(a,new HashSet<>());
            }
            Set<Book> Books = _authors.get(a);
            Books.add(b);
        }
    }

    private Map<Author,Set<Book>> _authors;

    public static double averageLength(Collection<String> strings)
    {
        int total = 0;
        for (String s : strings)
        {
            total += s.length();
        }
        return (double)total/strings.size();
    }

    public static List<String> oddFellows(List<String> strings)
    {
        List<String> result = new ArrayList<>();
        for (String s : strings)
        {
            if (s.length() % 2 == 1)
                result.add(s);
        }
        return result;
    }

    public static void main(String[] args)
    {
        List<String> Card = new ArrayList<>();
        Card.add("Collection of Authors");
        Card.add("A demonstration of Collection Hash Maps");
        Card.add("by Bram.");
        System.out.println(averageLength(Card));
        System.out.println(oddFellows(Card));
        Library l = new Library();
        Author fh = new Author("Frank Herbert");
        Author hg = new Author("HG Wells");
        Author ia = new Author("Isaac Asimov");
        Collection<Author> newAq = new ArrayList<>();
        newAq.add(fh);
        newAq.add(hg);
        newAq.add(ia);
        l.addAuthor(newAq);
        System.out.println(l._authors);
    }


}
