package edu.vtc.cis2271;

public class factorial {

        int factorial (int n) {
            if (n<2) return 1;
            return factorial (n-1)
                    *n;
        }
}
