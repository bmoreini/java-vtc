package edu.vtc.cis2271;

public class Main {
    // https://stackoverflow.com/questions/2559527/non-static-variable-cannot-be-referenced-from-a-static-context
    public static void main(String[] args) {
        System.out.print(factorial(5));
    }

    public static int factorial (int n) {
        if (n<2) return 1;
        return factorial (n-1)*n;
    }
}
