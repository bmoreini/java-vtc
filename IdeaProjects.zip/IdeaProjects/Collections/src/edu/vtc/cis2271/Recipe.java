/**
 * Recipe.java
 * Copyright 2016, Craig A. Damon
 * all rights reserved
 */
package edu.vtc.cis2271;

/**
 * Recipe - description
 * @author Craig A. Damon
 *
 */
public class Recipe
{
    public Recipe(String name)
    {
        _name = name;
    }

    public String toString()
    {
        return _name;
    }
    private String _name;
}
