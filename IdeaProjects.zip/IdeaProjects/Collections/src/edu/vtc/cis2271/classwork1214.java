package edu.vtc.cis2271;

public class classwork1214 {

    // Numeric Values
    //    37L = 0B011 = 077 = Ox3A = 1_000_000
    //    A leading zero makes it octal
    //    Octal = base 8
    //
    // String Values
    //    \n newline
    //    \r carriage return
    //    \t tab
    //    \a - alarm
    //
    // Char values
    //    'a'  '\n'  '\077'
    //
    // floats (floats faster) or Double
    //     add an f to make it a float
    //
    // boolean
    //
    // array
    //
    // variable = type name ; or type name = value;
    // operation - a single
    // and takes precedence over or
    // expression - a set of operations a variable is one
    //  Numeric Expressions
    //      primitives
    //      variables
    //      + - * / %
    //      INTEGER DIVISION THROWS AWAY THE REMAINDER!!
    //  String Expressions
    //      +
    //  Boolean Expressions
    //      && ||
    //  Comparison Operations
    //      == < <= !=
    //  Arrays
    //      array[3]=
    //      a.length
    //
    //  Method Call Expressions
    //      method name (args) .. e.g Math.sqrt(4.0)
    //      "abc".equals(2)
    //      "abc".equalsIgnoreCase
    //      .substring, . CarAt  .length()
    //
    //  static public return-type||void name (parameters) {statements}
    //
    //  IF/THEN/ELSE
    //  WHILE / BREAK / CONTINUE - might not do
    //  FOR ~ WHILE TRUE
    //  DO WHILE - do at least once
    //  FOR EACH ex for (int X : a) "Enhanced For Loop"
    //  Block = {statements}
    //  Return - go back from in middle of voice, or if returning an expression
    //
    //  CLASSES
    //      public class Name {}
    //      Methods
    //      Static (constant) or Non-Static (Instance) eg static string shared - same all - on the class name
    //      (Math field public static PI = 3.14)
    //      Fields (private)
    //      Constructors
    //      overload: Same name, different arguments
    //
    //  Constructor: public Name () {}
    //      this is within a non-static || instance methods e.g. this.data
    // EXCEPTIONS
    // try
    // catch
    // finally
    //
    // throw new Badx()
    // catch Badx e
    // Collections = objects (no primitives)
    // NO FILES, NO GUI

}
