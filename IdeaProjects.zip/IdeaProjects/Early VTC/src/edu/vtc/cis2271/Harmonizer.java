/**
 * Harmonizer.java
 * Copyright 2018, Craig A. Damon
 * all rights reserved
 */
package edu.vtc.cis2271;

import java.util.Scanner;

/**
 * Harmonizer - description
 * @author Craig A. Damon
 *
 */
public class Harmonizer
{

	/** description
	 * @param args
	 */
	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		
		System.out.println("Whic entry in the harmonic series do you want");
		int n = in.nextInt();
		
		double sum = 0;
		for (double k = 1; k <= n; k++)
			{
				sum += 1/k;
			}
		
		System.out.println("The answer is "+sum);
		
		in.close();
	}


	/** description
	 * @param args
	 */
	public static void main2(String[] args)
	{
		Scanner in = new Scanner(System.in);
		
		System.out.println("Which entry in the harmonic series do you want");
		int n = in.nextInt();
		
		double sum = 0;
		for (double k = 1; k <= n; k++)
			{
				sum += 1/k;
			}
		
		System.out.println("The answer is "+sum);
		
		in.close();
	}

}
