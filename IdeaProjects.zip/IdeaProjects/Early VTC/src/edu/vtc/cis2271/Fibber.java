/**
 * Fibber.java
 * Copyright 2018, Craig A. Damon
 * all rights reserved
 */
package edu.vtc.cis2271;

import java.util.Scanner;

/**
 * Fibber - description
 * @author Craig A. Damon
 *
 */
public class Fibber
{
   public static void main(String[] args)
   {
  	 Scanner in = new Scanner(System.in);
  	 
  	 System.out.println("Which Fibonacci number do you want?");
  	 int n = in.nextInt();
  	 
  	 int numPrev = 1;
  	 int num = 1;
  	 
  	 for (int i = 3; i <= n; i++)
  		 {
  			 int temp = num + numPrev;
  			 numPrev = num;
  			 num = temp;
  		 }
  	 
  	 System.out.println("Your number is "+num);
  	 
  	 in.close();
   }
}
