package com.bram;

public class Main {

    public static void main(String[] args) {
        int n = 0;
        int t = 0;
        boolean moreToDo = true;
        while (moreToDo) {
            System.out.println("More to do!");
            moreToDo = false;
        }
        // use "if (boolean) break" instead of set "boolean == true" to break a loop
        while (n < 3) {
            System.out.println(n);
            n++;
        }
        // initialization - every for loop tests at least once, though may not run.
        // init => test => body => increment => test => body => increment ....
        for (int b = 0; b < 3; b++) {
            System.out.println(b);
        }
        // simplify For
        for (; t < 5; t++) {
            System.out.println(t);
        }
    }
}
// do while: forces going through loop once
// break outer breaks out of outer loop
// continue outer means break inner and go to next outer
// break means brake inner
