package com.bram;
import java.util.Scanner;
public class Main {
    // this is a method
    public static void main(String[] args) {
        int fibN [] = {1, 1, 2};
        Scanner input = new Scanner(System.in);
        String lastFib = input.nextInt();
        System.out.println("End Fibs where?");
        lastFib= input.next();
        for (var i =4 ; i<= lastFib;i++) {
            fibN[i]=fibN[i-1]+fibN[i-2];
        }
        System.out.println("Value of Fib "+lastFib+" is "+fibN[lastFib]);
        input.close(); }
    }
