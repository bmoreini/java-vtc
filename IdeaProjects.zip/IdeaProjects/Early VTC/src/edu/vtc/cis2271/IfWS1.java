/**
 * IfWS1.java
 * Copyright 2015, Craig A. Damon
 * all rights reserved
 */
package edu.vtc.cis2271;

import java.util.Scanner;

/**
 * IfWS1 - description
 * @author Craig A. Damon
 *
 */
public class IfWS1
{

	/** simple example testing even/odd from if worksheet
	 * @param args
	 */
	public static void main(String[] args)
	{
	  Scanner input = new Scanner(System.in);

	  int n;
	  System.out.println("Please input an integer");
	  n = input.nextInt();
	  if (n % 2 ==  0)
	  	System.out.println(n+" is even");
	  else
	  	System.out.println(n+" is odd");
	  
	  input.close();
	}

}
