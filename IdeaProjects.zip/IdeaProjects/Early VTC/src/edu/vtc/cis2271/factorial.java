package com.bram;
import java.util.Scanner;
public class Main {
    // this is a method
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("What number?");
        int n = in.nextInt();
        int fact = 1;
        for (int i = 1; i <= n; i++) {
            fact *= i;
        }
        System.out.println(n + "  factorial = " + fact);
    }
}

//        String reply = input.next();
//        input.close(); }
//switch (reply)
// {
//  case"yes": // if you write nothing else it moves on to case "y"
//  case "y":
// }