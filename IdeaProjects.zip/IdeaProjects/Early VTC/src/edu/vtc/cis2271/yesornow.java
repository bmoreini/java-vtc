package com.bram;
import java.util.Scanner;
public class Main {
    // this is a method
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String answer = null;
        boolean foundAnswer = false;
        do {
            answer = in.next();
            if (answer.equalsIgnoreCase("yes") || answer.equalsIgnoreCase("no"))
                break;
            System.out.println("Yes or No please");
        }
        while (!foundAnswer);
        System.out.println("Your answer is " + answer);
    }
}
