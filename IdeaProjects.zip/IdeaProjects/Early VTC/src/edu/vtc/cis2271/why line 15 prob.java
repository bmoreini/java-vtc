package com.bram;
import java.util.Scanner;
public class Main {
    // this is a method
    public static void main(String[] args) {
        System.out.println("How many ears corn?");
        int ears;
        double price = .35;
        Scanner input = new Scanner(System.in);
        String reply = input.next();
        ears=Integer.parseInt(reply);
        if (ears < 12) price=.50;
        else if (ears < 24) price=.45;
        else if (ears < 36) price=.40;
        else if (ears > 35) price=.35;
        else price=.35;
        System.out.println("Price = $"+price*ears);
        input.close(); }
    }
//switch (reply)
// {
//  case"yes": // if you write nothing else it moves on to case "y"
//  case "y":
// }
//ASST:  Convert to Case statements