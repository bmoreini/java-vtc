/**
 * WhileE.java
 * Copyright 2018, Craig A. Damon
 * all rights reserved
 */
package edu.vtc.cis2271;

import java.util.Scanner;

/**
 * WhileE - description
 * @author Craig A. Damon
 *
 */
public class WhileE
{

	/** description
	 * @param args
	 */
	public static void main(String[] args)
	{
    Scanner in = new Scanner(System.in);
    
    int num;
    int sum = 0;
    
		System.out.println("Please input numbers, negative to exit");
		
		// either
		num = in.nextInt();
		while (num >= 0)
    	{
    		sum += num;
    		num = in.nextInt();
    	}
		
		// or
		/*
		 * while (true)
		 *    {
		 *       num = in.nextInt();
     *       if (num < 0)
     *          break;
     *       sum += num;
		 *    }
		 */
		
    
    System.out.println("Your numbers total "+sum);
    
    in.close();
	}

}
