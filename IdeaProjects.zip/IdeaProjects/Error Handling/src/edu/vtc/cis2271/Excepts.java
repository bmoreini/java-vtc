package edu.vtc.cis2271;

public class Excepts
{

    public static void main(String[] args)
    {
        Excepts xs= new Excepts(17);
        try {
            xs.doIt(22);
            xs.doIt(4);
            xs.doIt(13);
        }
        catch (IllegalArgumentException e)
        { System.out.println("oops");}
        System.out.println("all done");
        }

    public Excepts(int i)
    {
        this._data =i;
    }

    public void doIt(int x)
    {
        if (x < _data) throw new IllegalArgumentException();
        _data = x % _data;
        System.out.println("_data is now "+_data);
    }
    private int _data;
    }