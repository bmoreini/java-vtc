package edu.vtc.cis2271;

public class Risky {

    public void risky()
        throws MyBadEx
    {

        if (problem) {
            throw new MyBadEx("My Bad");
        }
    }

    public void foo() {
        myLock.aqcuire();

        try {
            risky();
            if (flag) return bar();
        }

        catch (myBadExp | OtherBadExp e) { // MultiCatch
            e.printStackTrace();
        }

        finally {
            myLock.release();
        }
    }
}
