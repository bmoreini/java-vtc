package edu.vtc.cis2271;
import java.io.IOException;
import java.util.Formatter;
import java.util.Formattable;


public class BankAccount implements Formattable {

    // System.out.printf("%3d",i)  - take up three spaces as a decimal number.  d = decimal, x = hex,
    // s = string, 3 = exp floating point, f = float, c = char
    // System.out.println(object) will look for a toString.  s is extended - so ("%7s",myObject) will call that method.

    public static void main(String[] args) throws IOException
        {
            BankAccount account = new BankAccount( 1892.3453 );
            System.out.println( "BankAccount " + account.getNumber() );
            System.out.println( "Has a balance of " + account.getBalance() );
            System.out.println(String.format( "%10.3s", account ));
        }

        public void formatTo(Formatter formatter, int flags, int width, int precision) {

        /* CharSequence is yet another interface that is implemented by (among others) the String class.
        Construct a string by first converting the bank balance into a string and then padding it with spaces
        so that it has the desired width. Pass that string to the append method.

         Enhance the formatTo method of Exercise ••• P9.3 by taking into account the precision.*/

            Appendable a = formatter.out();

            try
            {
                char dollar ='$';
                a.append(dollar);

                _balance=balanceToPrecision(precision);
                String Balance = balanceToString();

                while (width > Balance.length())
                    {
                        Balance = " " + Balance;
                    }

                a.append(Balance);

            }

            catch (IOException e)
            {
                e.printStackTrace();
            }
        }

    /**
     * Converts this balance value to the string.
     *
     * @return the balance, type of String
     */

    public String balanceToString() {
        return Double.toString( _balance );
    }

    public double balanceToPrecision (int precision) {
        double multiplier = Math.pow(10, precision);
        int leftSide = (int) _balance;
        double rightSide = _balance - leftSide;
        rightSide *= multiplier;
        int rightSideInt = (int) rightSide;
        _balance=(double) (leftSide) + (double) (rightSideInt)/multiplier;
        return _balance;
    }

    /**
     * Defines the BankAccount object.
     *
     */
    public BankAccount(double initialBalance) {
        _balance = initialBalance;
        _accountNumber = _lastAccountNumber + 1;
        _lastAccountNumber = _accountNumber;
    }

    public int getNumber() {
        return _accountNumber;
    }

    public double getBalance() {
        return _balance;
    }

    private double _balance;
    private int _accountNumber;
    private int _lastAccountNumber = 0;

}