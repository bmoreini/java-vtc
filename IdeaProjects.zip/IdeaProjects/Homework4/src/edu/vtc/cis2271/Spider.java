package edu.vtc.cis2271;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Scanner;
import java.net.URL;


/**
 This program prints all lines from a web page that contain
 references to other web sites.
 */
public class Spider {

    public static void main(String[] args) throws IOException {
        String address = "http://gamefacewebdesign.com/spot-on.html";
        Spider.maxLevel=1;
        Spider(address, Spider.maxLevel);
    }
    public static int maxLevel;
    public static String indent;

    private static void Spider(String address, Integer level) throws IOException {
        String newAddress;

        URL pageLocation = new URL(address);
        Scanner in = new Scanner(pageLocation.openStream());
        while (in.hasNext()) {
            String line = in.next();
            if (line.contains("<body")) {
                while (in.hasNext()) {
                    line = in.next();
                    if (line.contains("href=\"http://")) {
                        int from = line.indexOf("\"");
                        int to = line.lastIndexOf("\"");
                        newAddress = line.substring(from + 1, to);
                        int indents=Spider.maxLevel-level;
                        Spider.indent="";
                        for (int i=0;i<indents;i++){
                            Spider.indent=Spider.indent+"     ";
                        }
                        try {
                            System.out.println(Spider.indent+"<a href=\""+newAddress+"\">"+newAddress+"</a>");
                            if (level > 0) {
                                Spider(newAddress, level - 1);
                            }
                        } catch (IOException error) {
                            System.out.println("Bad URL ^");
                        }
                    }
                }
            }
        }
    }
}



