/**
 * YahtzeeGame.java
 * Copyright 2015, Craig A. Damon
 * all rights reserved
 */
package edu.vtc.cis2271.yahtzee;

import java.util.Random;

/**
 * YahtzeeGame - the basic state of the game
 * @author Craig A. Damon
 *
 */
public class YahtzeeGame
{

    /**
     * create a new. empty game
     */
    public YahtzeeGame()
    {
        _score = new edu.vtc.cis2271.yahtzee.Scoresheet();
        _random = new Random();
        _lastRoll = null;
    }

    /**
     * get the scoresheet for the current game
     * @return the scoresheet, never null
     */
    public edu.vtc.cis2271.yahtzee.Scoresheet getScoreSheet()
    {
        return _score;
    }

    /**
     * generate an initial dice roll
     * @return the array of 5 "dice" (ints from 1 to 6)
     */
    public int[] getRoll()
    {
        int[] dice = new int[5];
        for (int i = 0; i < dice.length; i++)
            dice[i] = _random.nextInt(6)+1;
        _lastRoll = dice;
        return dice;
    }

    /**
     * re-roll the indicated dice
     * @param keep the array indicating which dice to keep
     * @return the array of 5 "dice" after the re-roll, combining new values with the kept old values
     */
    public int[] getReRoll(boolean[] keep)
    {
        int[] newDice = new int[5];
        for (int i = 0; i < newDice.length; i++)
        {
            if (keep[i])
                newDice[i] = _lastRoll[i];
            else
                newDice[i] = _random.nextInt(6)+1;
        }
        _lastRoll = newDice;
        return newDice;
    }

    /**
     * apply the last roll to the indicated category on the score sheet
     * @param category the category to use, never null, must not be already in use
     */
    public void applyRoll(edu.vtc.cis2271.yahtzee.Scoresheet.Category category)
    {
        if (_score.isUsed(category))
            throw new IllegalArgumentException(category+" is already used");
        _score.useRoll(category,_lastRoll);
        _lastRoll = null;
    }

    /** has this game finished?
     * @return true if it has finished, false otherwise
     */
    public boolean isCompleted()
    {
        return _score.isCompleted();
    }

    private edu.vtc.cis2271.yahtzee.Scoresheet _score;  // the current score, never null
    private Random _random;     // the random number generator to use for all the dice rolls
    private int[] _lastRoll;    // the 5 dice most recent rolled, set to null after a roll is used
}
