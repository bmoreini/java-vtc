/**
 * DieDisplay.java
 * Copyright 2015, Craig A. Damon
 * all rights reserved
 */
package edu.vtc.cis2271.yahtzee;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.util.Random;

import javax.swing.JPanel;
import javax.swing.border.LineBorder;

/**
 * DieDisplay - display a single die on the screen.
 * This die knows the current number it is set to
 * and can animate rolling to a new number.
 * @author Craig A. Damon
 *
 */
public class DieDisplay extends JPanel
{

    /**
     * requirement for JComponents because they are serializable
     */
    private static final long serialVersionUID = -4068760669536849258L;

    /**
     * create a die with a random initial value
     */
    public DieDisplay()
    {
        _random = new Random();
        _number = _random.nextInt(6)+1;
        initDieDisplay();
    }

    /**
     * create a die with an indicated initial value
     * @param value the value from 1 to 6
     */
    public DieDisplay(int value)
    {
        _random = new Random();
        _number = value;
        initDieDisplay();
    }

    /** set up the visual display
     */
    private void initDieDisplay()
    {
        Dimension size = new Dimension(32,32);
        setMinimumSize(size);
        setPreferredSize(size);
        setMaximumSize(size);
        setBackground(Color.WHITE);
        setBorder(new LineBorder(Color.BLACK,1));
    }

    /**
     * display the die
     * @param g the graphics display control
     * @see javax.swing.JComponent#paintComponent(java.awt.Graphics)
     */
    @Override
    protected void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        switch (_number)
        {
            case 1:
                drawPip(g,4);
                break;
            case 2:
                drawPip(g,3);
                drawPip(g,5);
                break;
            case 3:
                drawPip(g,0);
                drawPip(g,4);
                drawPip(g,8);
                break;
            case 4:
                drawPip(g,0);
                drawPip(g,2);
                drawPip(g,6);
                drawPip(g,8);
                break;
            case 5:
                drawPip(g,0);
                drawPip(g,2);
                drawPip(g,4);
                drawPip(g,6);
                drawPip(g,8);
                break;
            case 6:
                drawPip(g,0);
                drawPip(g,1);
                drawPip(g,2);
                drawPip(g,6);
                drawPip(g,7);
                drawPip(g,8);
                break;
        }
    }

    /**
     * set the value of the die to the indicated number
     * @param value the new displayed value of the die
     */
    public void setValue(int value)
    {
        _number = value;
        repaint();
    }


    /**
     * set the value of the die to the indicated number after displaying random values for some time
     * @param ms the number of milliseconds to display random values
     * @param value the new displayed value of the die
     */
    public void rollToValue(int ms,int value)
    {
        Thread th = new Thread(()->animateRolling(ms,value));
        th.start();
    }

    /** actually animate the rolling
     * @param ms
     * @param value
     */
    private void animateRolling(int ms, int value)
    {
        for (int i = 0; i < ms; i += 100)
        {
            _number = _random.nextInt(6)+1;
            repaint();
            try
            {
                Thread.sleep(100);
            }
            catch (InterruptedException e)
            {
                // goto next iteration immediately
            }
        }
        _number = value;
        repaint();
    }


    /** draw a single dot on the die
     * @param g the graphics, never null
     * @param pos the position from 0 to 8, with 0 to being top row, left to right,
     * 3-5 being middle row and 6-8 being bottom row
     */
    private void drawPip(Graphics g, int pos)
    {
        g.setColor(Color.BLACK);
        int dotSize = getWidth()/8;
        int vSpace = (getHeight()-dotSize*3)/4;
        int top = vSpace+(vSpace+dotSize)*(pos/3); // pos/3 is row
        int hSpace = (getWidth()-dotSize*3)/4;
        int left = hSpace + (hSpace+dotSize)*(pos%3);  // pos%3 is column
        g.fillOval(left,top,dotSize,dotSize);
    }


    private int _number;  // always from 1 to 6
    private final Random _random; // never null
}
