/**
 * Scoresheet.java
 * Copyright 2015-2017, Craig A. Damon
 * all rights reserved
 */
package edu.vtc.cis2271.yahtzee;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Scoresheet - a scoresheet for a single yahtzee player
 * @author Craig A. Damon
 *
 */
public class Scoresheet
{

    private static final int SMALL_STRAIGHT_SCORE = 30;
    private static final int LARGE_STRAIGHT_SCORE = 40;
    private static final int FULL_HOUSE_SCORE = 25;
    private static final int YAHTZEE_SCORE = 50;
    private static final int TOP_HALF_BONUS = 35;
    private static final int TOP_HALF_BONUS_LEVEL = 63;

    /**
     * ScoresheetCategory - the categories available for a scoresheet
     * @author Craig A. Damon
     *
     */
    @SuppressWarnings("javadoc")
    public enum Category {
        Ones,Twos,Threes,Fours,Fives,Sixes,
        SmallStraight,LargeStraight,ThreeOfKind,FourOfKind, FullHouse, Yahtzee,Chance
    }


    /**
     * initialize an empty scoresheet
     */
    public Scoresheet()
    {
        _scores = new int[Category.values().length];
        _listeners = new ArrayList<>();
        for (int i = 0; i < _scores.length; i++)
            _scores[i] = -1;
    }


    /** add a listener to be notified when the score changes
     * @param listener the listener, never null
     */
    public void addScoreSheetListener(ScoreSheetListener listener)
    {
        _listeners.add(listener);
    }

    /**
     * remove a listener from being notified about changes to this score sheet
     * @param listener the listener, never null
     */
    public void removeScoreSheetListener(ScoreSheetListener listener)
    {
        _listeners.remove(listener);
    }

    /**
     * notify all the listeners about a change to the score
     * @param c the category that has changed, never null
     */
    private void notifyListeners(Category c)
    {
        for (ScoreSheetListener listener : _listeners)
        {
            listener.updateScore(c);
        }
    }

    /**
     * has this category been used thus far
     * @param category the category in the scoresheet in question
     * @return true if the category has been used
     */
    public boolean isUsed(Category category)
    {
        return _scores[category.ordinal()] >= 0;
    }

    /**
     * has this scoresheet been completed (has every category been used)
     * @return true if completed, false if one or more categories are still empty
     */
    public boolean isCompleted()
    {
        for (int score : _scores)
        {
            if (score < 0)
                return false;
        }
        return true;
    }

    /**
     * return the score for a category that has been used
     * @param category the category in question
     * @return the score of the category if it has been used, returns an undefined value if isUsed(category) is false.
     */
    public int getScore(Category category)
    {
        return _scores[category.ordinal()];
    }

    /**
     * get the bonus level for the top half score
     * @return the bonus or 0 if no bonus has been earned
     */
    public int getTopBonus()
    {
        if (getTopScore() >= TOP_HALF_BONUS_LEVEL)
            return TOP_HALF_BONUS;
        else
            return 0;
    }

    /** does changing the indicated category impact the top bonus
     * @param category the category in question, never null
     * @return true if this category impacts the top bonus
     */
    public boolean impactsTopBonus(Category category)
    {
        return category.ordinal() >= Category.Ones.ordinal() &&
                category.ordinal() <= Category.Sixes.ordinal();
    }

    /**
     * get all the categories that have not yet been used
     * @return the set, never null, may be empty if game is finished
     */
    public Set<Category> unusedCategories()
    {
        Set<Category> result = new HashSet<>();
        Category[] values = Category.values();
        for (int i = 0; i < values.length; i++)
        {
            if (_scores[i] < 0)
                result.add(values[i]);
        }
        return result;
    }

    /**
     * use the indicated set of dice in the indicated (unused) category
     * @param category the category where this dice roll should be used
     * @param dice the dice to use in this category. Must have length == 5
     * @return true if the category was unused
     */
    public boolean useRoll(Category category,int[] dice)
    {
        if (_scores[category.ordinal()] >= 0)
            return false;
        _scores[category.ordinal()] = computeValue(category,dice);
        notifyListeners(category);
        return true;
    }

    /**
     * compute the point value for using these dice in the indicated category
     * @param category the scoresheet category
     * @param dice the dice to use, the length must be 5
     * @return the point value, >= 0
     */
    public int computeValue(Category category,int[] dice)
    {
        switch (category)
        {
            case Ones:
                return countDiceOf(1,dice);
            case Twos:
                return countDiceOf(2,dice)*2;
            case Threes:
                return countDiceOf(3,dice)*3;
            case Fours:
                return countDiceOf(4,dice)*4;
            case Fives:
                return countDiceOf(5,dice)*5;
            case Sixes:
                return countDiceOf(6,dice)*6;
            case SmallStraight:
                if (isSmallStraight(dice))
                    return SMALL_STRAIGHT_SCORE;
                return 0;
            case LargeStraight:
                if (isLargeStraight(dice))
                    return LARGE_STRAIGHT_SCORE;
                return 0;
            case ThreeOfKind:
                if (isThreeOfKind(dice))
                    return countTotalOfDice(dice);
                return 0;
            case FourOfKind:
                if (isFourOfKind(dice))
                    return countTotalOfDice(dice);
                return 0;
            case Yahtzee:
                if (isFiveOfKind(dice))
                    return YAHTZEE_SCORE;
                return 0;
            case FullHouse:
                if (isFullHouse(dice))
                    return FULL_HOUSE_SCORE;
                return 0;
            case Chance:
                return countTotalOfDice(dice);
        }
        return 0;
    }

    /**
     * get the total score for this scoresheet as it currently stands
     * @return the score, >= 0
     */
    public int getTotalScore()
    {
        return getTopScore() + getBottomScore();
    }

    /** get the score from the top half of the scoresheet
     * @return the total of the top half
     */
    private int getTopScore()
    {
        int score = 0;
        for (int i = Category.Ones.ordinal(); i <= Category.Sixes.ordinal(); i++)
        {
            if (_scores[i] > 0)
                score += _scores[i];
        }
        if (score > TOP_HALF_BONUS_LEVEL)
            score += TOP_HALF_BONUS;
        return score;
    }

    /** get the score from the bottom half
     * @return
     */
    private int getBottomScore()
    {
        int score = 0;
        for (int i = Category.SmallStraight.ordinal(); i <= Category.Chance.ordinal(); i++)
        {
            if (_scores[i] > 0)
                score += _scores[i];
        }
        return score;
    }

    /** count the total value for the dice of the indicated count
     * @param count the count to be used to look for dice
     * @param dice the dice to consider, always length == 5
     * @return the number of dice with value == count
     */
    private int countDiceOf(int count, int[] dice)
    {
        // TODO -- make this method actually calculate the correct answer
        return 0;
    }

    /**
     * return the total of the five dice
     * @param dice the dice, always has length = 5
     * @return the sum of the dice
     */
    private int countTotalOfDice(int[] dice)
    {
        // TODO -- make this method actually calculate the correct answer
        return 0;
    }

    /**
     * do these dice contain 3 (or more) of the value
     * @param dice the array of 5 dice, valued from 1 to 6
     * @return true if at least 3 of the dice have the same value
     */
    private boolean isThreeOfKind(int[] dice)
    {
        // TODO -- make this method actually calculate the correct answer
        return false;
    }

    /**
     * do these dice contain 4 (or more) of the value
     * @param dice the array of 5 dice, valued from 1 to 6
     * @return true if at least 4 of the dice have the same value
     */
    private boolean isFourOfKind(int[] dice)
    {
        // TODO -- make this method actually calculate the correct answer
        return false;
    }

    /**
     * do these dice all contain the same value
     * @param dice the array of 5 dice, valued from 1 to 6
     * @return true if the 5 dice all have the same value
     */
    private boolean isFiveOfKind(int[] dice)
    {
        // TODO -- make this method actually calculate the correct answer
        return false;
    }

    /**
     * return true if the dice represent a small straight, that is 4 of the dice have consecutive values (not necessarily in order)
     * @param dice the 5 dice, valued from 1 to 6
     * @return true if the dice contain a small straight
     */
    private boolean isSmallStraight(int[] dice)
    {
        boolean hasOne;
        boolean hasTwo;
        boolean hasFive;
        boolean hasSix;
        /* every straight must have 3 and 4 */
        if (countDiceOf(3,dice) < 1)
            return false;
        if (countDiceOf(4,dice) < 1)
            return false;
        hasOne = countDiceOf(1,dice) >= 1;
        hasTwo = countDiceOf(2,dice) >= 1;
        hasFive = countDiceOf(5,dice) >= 1;
        hasSix = countDiceOf(6,dice) >= 1;
        return (hasOne && hasTwo) || (hasTwo && hasFive) || (hasFive && hasSix);
    }

    /**
     * do these dice contain a large straight, that is the values from 1..5 or 2..6
     * @param dice the 5 dice, valued from 1 to 6
     * @return true if the dice contain a large straight
     */
    private boolean isLargeStraight(int[] dice)
    {
        int d;
        boolean hasOne = countDiceOf(1,dice) == 1;
        boolean hasSix = countDiceOf(6,dice) == 1;
        if (hasOne == hasSix)
            return false;  /* need exactly one die at either 1 or 6 */
        /* also need one of each other number */
        for (d = 2; d <= 5; d++)
        {
            if (countDiceOf(d,dice) != 1)
                return false;
        }
        return true;
    }

    /**
     * does the dice contain a full house (2 of one value and the other 3 of a second value)
     * @param dice the 5 dice, valued from 1 to 6
     * @return true if the dice contain a full house
     */
    private boolean isFullHouse(int[] dice)
    {
        boolean hasPair = false, hasThree = false;
        for (int d = 1; d <= 6; d++)
        {
            int count = countDiceOf(d,dice);
            if (count == 2)
                hasPair = true;
            else if (count == 3)
                hasThree = true;
            else if (count > 0)
                return false;
        }
        return hasPair && hasThree;
    }

    private int[] _scores;  // holds the score, by category, or -1 if unused thus far
    private final List<ScoreSheetListener> _listeners;   // the listeners who will be notified if any scoring changes, never null, contains no nulls
}
