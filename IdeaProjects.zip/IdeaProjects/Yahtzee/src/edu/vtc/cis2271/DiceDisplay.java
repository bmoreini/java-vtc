/**
 * DiceDisplay.java
 * Copyright 2015-2017, Craig A. Damon
 * all rights reserved
 */
package edu.vtc.cis2271.yahtzee;

import java.awt.BorderLayout;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JPanel;

/**
 * DiceDisplay - display the five dice for a single turn of yahtzee
 * @author Craig A. Damon
 *
 */
public class DiceDisplay extends JPanel
{
    private static final long serialVersionUID = 2251148005824463126L;

    /**
     * create the display panel
     * @param rollAction the action to take if the roll button is pressed
     * @param rerollAction the action to take if the re-roll button is pressed
     */
    public DiceDisplay(ActionListener rollAction,ActionListener rerollAction)
    {
        super(new BorderLayout(),true);
        _selects = new JCheckBox[5];
        _dice = new DieDisplay[5];

        // TODO -- create the layout for the dice panel
        // in doing so, the code must create the 5 DieDisplay objects and the 5 check boxes
        // and put them into two arrays (_selects for the check boxes and _dice for the Die displays)
        // it must also create the two button (Roll and ReRoll), put them into _roll and _reroll fields
        // and attach the actionlisteners that were passed in to the corresponding buttons
    }

    /**
     * setup the UI to be ready to roll
     */
    public void enableRoll()
    {
        _roll.setEnabled(true);
        _reroll.setEnabled(false);
    }

    /**
     * tell the dice display to set the values
     * @param dice the 5 dice that should be displayed in the roll
     */
    public void setRoll(int dice[])
    {
        for (int i = 0; i < 5; i++)
        {
            _dice[i].rollToValue(1000,dice[i]);
            _selects[i].setSelected(false);
            _selects[i].setEnabled(true);
        }
    }

    /**
     * set up the UI to be ready for the user to request re-rolling selected dice
     */
    public void enableReRoll()
    {
        _roll.setEnabled(false);
        _reroll.setEnabled(true);
    }

    /**
     * update the dice the user requested to be re-rolled
     * @param dice the complete array of 5 dice values
     * @param allowSelects if true, allow the dice to be selected for another roll
     */
    public void setReRoll(int dice[],boolean allowSelects)
    {
        for (int i = 0; i < 5; i++)
        {
            if (!_selects[i].isSelected())
            {
                _dice[i].rollToValue(1000,dice[i]);
                _selects[i].setSelected(false);
            }
            _selects[i].setEnabled(allowSelects);
        }
    }

    /**
     * turn off the ability to re-roll
     */
    public void disableReRoll()
    {
        _reroll.setEnabled(false);
    }

    /**
     * get the current state of the selections for which dice to keep
     * @return the array of 5 booleans, each true means the corresponding die should be kept (not re-rolled)
     */
    public boolean[] getSelected()
    {
        boolean selected[] = new boolean[5];
        for (int i = 0; i < 5; i++)
            selected[i] = _selects[i].isSelected();
        return selected;
    }

    private JCheckBox[] _selects;  // the checkboxes indicating which dice to keep
    private DieDisplay[] _dice;    // the dice controllers themselves
    private JButton _roll;         // the roll button
    private JButton _reroll;       // the re-roll button
}
