/**
 * ScoreSheetListener.java
 * Copyright 2015, Craig A. Damon
 * all rights reserved
 */
package edu.vtc.cis2271.yahtzee;

/**
 * ScoreSheetListener - listen for changes to a scoresheet
 * @author Craig A. Damon
 *
 */
public interface ScoreSheetListener
{
    /**
     * announce that a score sheet category scoring has changed
     * @param c the category being changed, never null
     */
    public void updateScore(edu.vtc.cis2271.yahtzee.Scoresheet.Category c);
}
