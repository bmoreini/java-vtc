/**
 * ScoreSheetDisplay.java
 * Copyright 2015, Craig A. Damon
 * all rights reserved
 */
package edu.vtc.cis2271.yahtzee;

import java.awt.Component;
import java.util.HashMap;
import java.util.Map;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import edu.vtc.cis2271.yahtzee.Scoresheet.Category;

/**
 * ScoreSheetDisplay - a display component to show the state of a single scoresheet
 * @author Craig A. Damon
 *
 */
public class ScoreSheetDisplay extends JPanel implements ScoreSheetListener
{
    /**
     * Requirements for JComponents because they are serializable
     */
    private static final long serialVersionUID = -2149257177339810310L;

    /**
     * @param score the score sheet being displayed
     * @param select the action to perform when a category is selected
     */
    public ScoreSheetDisplay(edu.vtc.cis2271.yahtzee.Scoresheet score, edu.vtc.cis2271.yahtzee.CategorySelection select)
    {
        _score = score;
        _selectors = new HashMap<>();
        score.addScoreSheetListener(this);
        Box sections = new Box(BoxLayout.Y_AXIS);
        add(sections);
        sections.add(createTopSection(select));
        sections.add(createBottomSection(select));
        sections.add(createTotalField());
    }

    /** create the fields to display the top scores
     * @return the outermost container of the scores
     */
    private JComponent createTopSection(edu.vtc.cis2271.yahtzee.CategorySelection select)
    {
        Box top = new Box(BoxLayout.Y_AXIS);
        top.add(Box.createVerticalStrut(10));

        Box topRow = new Box(BoxLayout.X_AXIS);
        top.add(topRow);
        topRow.add(Box.createGlue());
        topRow.add(Box.createHorizontalStrut(10));
        _onesScore = createScoreField(topRow, Category.Ones, "Ones",select);
        topRow.add(Box.createHorizontalStrut(10));
        _twosScore = createScoreField(topRow, Category.Twos, "Twos",select);
        topRow.add(Box.createHorizontalStrut(10));
        _threesScore = createScoreField(topRow, Category.Threes, "Threes",select);
        topRow.add(Box.createHorizontalStrut(10));
        topRow.add(Box.createGlue());

        top.add(Box.createVerticalStrut(10));

        Box secondRow = new Box(BoxLayout.X_AXIS);
        top.add(secondRow);
        secondRow.add(Box.createGlue());
        secondRow.add(Box.createHorizontalStrut(10));
        _foursScore = createScoreField(secondRow, Category.Fours, "Fours",select);
        secondRow.add(Box.createHorizontalStrut(10));
        _fivesScore = createScoreField(secondRow, Category.Fives, "Fives",select);
        secondRow.add(Box.createHorizontalStrut(10));
        _sixesScore = createScoreField(secondRow, Category.Sixes, "Sixes",select);
        secondRow.add(Box.createHorizontalStrut(10));
        secondRow.add(Box.createGlue());

        top.add(Box.createVerticalStrut(10));

        Box bottomRow = new Box(BoxLayout.X_AXIS);
        top.add(bottomRow);
        bottomRow.add(Box.createGlue());
        bottomRow.add(Box.createHorizontalStrut(20));
        bottomRow.add(new JLabel("Bonus:"));
        bottomRow.add(Box.createHorizontalStrut(3));
        _upperBonusScore = new JTextField("0",2);
        _upperBonusScore.setEditable(false);
        _upperBonusScore.setMaximumSize(_upperBonusScore.getPreferredSize());
        bottomRow.add(_upperBonusScore);
        bottomRow.add(Box.createHorizontalStrut(30));

        top.add(Box.createVerticalStrut(10));

        return top;
    }

    /** description
     * @param row
     * @param score
     * @param label
     */
    private JTextField createScoreField(Box row, Category category, String label, edu.vtc.cis2271.yahtzee.CategorySelection select)
    {
        Box elems = new Box(BoxLayout.Y_AXIS);
        elems.setAlignmentX(CENTER_ALIGNMENT);
        row.add(elems);
        Box scorePart = new Box(BoxLayout.X_AXIS);
        scorePart.setAlignmentY(CENTER_ALIGNMENT);
        elems.add(scorePart);
        JTextField score = new JTextField(2);
        score.setEditable(false);
        score.setMaximumSize(score.getPreferredSize());
        scorePart.add(new JLabel(label+":"));
        scorePart.add(Box.createHorizontalStrut(3));
        scorePart.add(score);
        JButton selector = new JButton("Select");
        selector.addActionListener((e)->select.categorySelected(category));
        elems.add(selector);
        _selectors.put(category,selector);
        return score;
    }

    /** description
     * @return
     */
    private JComponent createBottomSection(edu.vtc.cis2271.yahtzee.CategorySelection select)
    {
        Box bottom = new Box(BoxLayout.Y_AXIS);
        bottom.add(Box.createVerticalStrut(10));

        Box topRow = new Box(BoxLayout.X_AXIS);
        bottom.add(topRow);
        topRow.add(Box.createGlue());
        topRow.add(Box.createHorizontalStrut(10));
        _smallStraightScore = createScoreField(topRow,Category.SmallStraight,"Small Straight",select);
        topRow.add(Box.createHorizontalStrut(10));
        _largeStraightScore = createScoreField(topRow,Category.LargeStraight,"Large Straight",select);
        topRow.add(Box.createHorizontalStrut(10));
        _fullHouseScore = createScoreField(topRow,Category.FullHouse,"Full House",select);
        topRow.add(Box.createHorizontalStrut(10));
        topRow.add(Box.createGlue());

        bottom.add(Box.createVerticalStrut(10));

        Box secondRow = new Box(BoxLayout.X_AXIS);
        bottom.add(secondRow);
        secondRow.add(Box.createGlue());
        secondRow.add(Box.createHorizontalStrut(10));
        _threeOfKindScore = createScoreField(secondRow,Category.ThreeOfKind,"3 of Kind",select);
        secondRow.add(Box.createHorizontalStrut(10));
        _fourOfKindScore = createScoreField(secondRow,Category.FourOfKind,"4 of Kind",select);
        secondRow.add(Box.createHorizontalStrut(10));
        _yahtzeeScore = createScoreField(secondRow,Category.Yahtzee,"Yahtzee",select);
        secondRow.add(Box.createHorizontalStrut(10));
        _chanceScore = createScoreField(secondRow,Category.Chance,"Chance",select);
        secondRow.add(Box.createHorizontalStrut(10));
        secondRow.add(Box.createGlue());

        bottom.add(Box.createVerticalStrut(10));

        return bottom;
    }

    /** description
     * @return
     */
    private Component createTotalField()
    {
        Box totalRow = new Box(BoxLayout.X_AXIS);
        totalRow.add(Box.createGlue());
        totalRow.add(Box.createHorizontalStrut(20));
        totalRow.add(new JLabel("Total:"));
        totalRow.add(Box.createHorizontalStrut(3));
        _totalScore = new JTextField("0",2);
        _totalScore.setMaximumSize(_totalScore.getPreferredSize());
        _totalScore.setEditable(false);
        totalRow.add(_totalScore);
        totalRow.add(Box.createHorizontalStrut(30));
        return totalRow;
    }

    /**
     * enable all the selectors that are still available in the scoresheet
     */
    public void enableSelectors()
    {
        // TODO -- make this code actually enable or disable the selectors
        // this code will need to use the _selectors map that will already be created and filled
    }

    /**
     * disable all the selectors
     */
    public void disableSelectors()
    {
        // TODO -- make this code actually disable all the selectors
        // this code will need to use the _selectors map that will already be created and filled
    }

    /**
     * get the scoresheet being displayed
     * @return the scoresheet, never null
     */
    public edu.vtc.cis2271.yahtzee.Scoresheet getScoreSheet()
    {
        return _score;
    }

    /**
     * set the scoresheet to display
     * @param score the scoresheet, never null
     */
    public void setScoresheet(edu.vtc.cis2271.yahtzee.Scoresheet score)
    {
        if (_score != null)
            _score.removeScoreSheetListener(this);
        _score = score;
        updateAllScores();
        score.addScoreSheetListener(this);
    }

    /**
     * completely update all the scores on the display from the underlying scoresheet
     *
     */
    public void updateAllScores()
    {
        for (Category c : Category.values())
            updateScore(c);
    }

    /**
     * update a single score (and any dependent scores)
     * @param category the category of score to update, never null
     * @see edu.vtc.cis2271.yahtzee.ScoreSheetListener#updateScore(edu.vtc.cis2271.yahtzee.Scoresheet.Category)
     */
    @Override
    public void updateScore(Category category)
    {
        JTextField score = getCategoryDisplay(category);
        String scoreStr = " ";
        if (_score.isUsed(category))
            scoreStr = String.valueOf(_score.getScore(category));
        score.setText(scoreStr);
        if (_score.impactsTopBonus(category))
            _upperBonusScore.setText(String.valueOf(_score.getTopBonus()));
        _totalScore.setText(String.valueOf(_score.getTotalScore()));
    }

    /**
     * get the display field for a given category
     * @param category the category, never null
     * @return the label where the text will be displayed, never null
     */
    private JTextField getCategoryDisplay(edu.vtc.cis2271.yahtzee.Scoresheet.Category category)
    {
        switch (category)
        {
            case Ones:
                return _onesScore;
            case Twos:
                return _twosScore;
            case Threes:
                return _threesScore;
            case Fours:
                return _foursScore;
            case Fives:
                return _fivesScore;
            case Sixes:
                return _sixesScore;
            case SmallStraight:
                return _smallStraightScore;
            case LargeStraight:
                return _largeStraightScore;
            case FullHouse:
                return _fullHouseScore;
            case ThreeOfKind:
                return _threeOfKindScore;
            case FourOfKind:
                return _fourOfKindScore;
            case Yahtzee:
                return _yahtzeeScore;
            case Chance:
                return _chanceScore;
        }
        return null;
    }

    private edu.vtc.cis2271.yahtzee.Scoresheet _score;

    // the map of the selectors, one for each category
    private Map<Category,JButton> _selectors;

    // all the individual display fields
    private JTextField _onesScore;
    private JTextField _twosScore;
    private JTextField _threesScore;
    private JTextField _foursScore;
    private JTextField _fivesScore;
    private JTextField _sixesScore;

    private JTextField _upperBonusScore;

    private JTextField _smallStraightScore;
    private JTextField _largeStraightScore;
    private JTextField _threeOfKindScore;
    private JTextField _fourOfKindScore;
    private JTextField _fullHouseScore;
    private JTextField _yahtzeeScore;
    private JTextField _chanceScore;

    private JTextField _totalScore;
}
