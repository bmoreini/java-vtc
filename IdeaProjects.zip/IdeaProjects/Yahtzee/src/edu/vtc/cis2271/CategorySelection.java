/**
 * CategorySelection.java
 * Copyright 2015, Craig A. Damon
 * all rights reserved
 */
package edu.vtc.cis2271.yahtzee;

import edu.vtc.cis2271.yahtzee.Scoresheet.Category;

/**
 * CategorySelection - capture a selection of a Category
 * @author Craig A. Damon
 *
 */
@FunctionalInterface
public interface CategorySelection
{
    /**
     * indicate that the given category was selected
     * @param category the selection, never null
     */
    public void categorySelected(Category category);
}
