/**
 * YahtzeeWindow.java
 * Copyright 2015-2017, Craig A. Damon
 * all rights reserved
 */
package edu.vtc.cis2271.yahtzee;

import java.awt.HeadlessException;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JTextField;

import edu.vtc.cis2271.yahtzee.Scoresheet.Category;

/**
 * YahtzeeWindow - the main window for the yahtzee game,
 * this also serves as the controller in an MVC model, connecting the game and scoresheet (model) to the DiceDisplay and ScoresheetDisplay (view)
 * @author Craig A. Damon
 *
 */
public class YahtzeeWindow extends JFrame
{
    private static final long serialVersionUID = 7571188632847109833L;

    /**
     * @param scoresheet the scoresheet, never null
     * @param game the yahtzee game itself
     * @throws HeadlessException
     */
    public YahtzeeWindow(edu.vtc.cis2271.yahtzee.Scoresheet scoresheet, edu.vtc.cis2271.yahtzee.YahtzeeGame game) throws HeadlessException
    {
        super("Yahtzee");
        Box layout = new Box(BoxLayout.Y_AXIS);
        _score = new edu.vtc.cis2271.yahtzee.ScoreSheetDisplay(scoresheet,(c)->categorySelected(c));
        _score.disableSelectors();
        _dice = new edu.vtc.cis2271.yahtzee.DiceDisplay((e)->doRoll(),(e)->doReRoll());
        _dice.enableRoll();
        _game = game;
        _message = new JTextField();
        _message.setEditable(false);
        layout.add(_score);
        layout.add(_dice);
        layout.add(_message);
        _message.setText("Roll the dice, see what you get");
        add(layout);
        pack();
        addWindowListener(new CloseUp());
    }

    /**
     * tell the game to perform a roll action and then update the state of the UI
     */
    public void doRoll()
    {
        _rerolls = 0;
        int[] dice = _game.getRoll();
        _dice.setRoll(dice);
        _dice.enableReRoll();
        _message.setText("Select the dice you want to keep and roll again");
    }

    /**
     * tell the game to do a re-roll action and then update the state of the UI
     */
    public void doReRoll()
    {
        int[] dice = _game.getReRoll(_dice.getSelected());
        _dice.setReRoll(dice,_rerolls == 0);
        _rerolls++;
        if (_rerolls > 1)
        {
            _dice.disableReRoll();
            _score.enableSelectors();
            _message.setText("Where would you like to use these dice?");
        }
    }

    /**
     * commit the last roll to a category by telling the game to do so.
     * This also will update the UI appropriately
     * @param c the category where the last roll should be applied
     */
    public void categorySelected(Category c)
    {
        _game.applyRoll(c);
        _score.disableSelectors();
        if (_game.isCompleted())
        {
            _message.setText("Thank you for playing");
            return;
        }
        _dice.enableRoll();
        _message.setText("Roll again for your next turn");
    }

    private final edu.vtc.cis2271.yahtzee.ScoreSheetDisplay _score;
    private final edu.vtc.cis2271.yahtzee.DiceDisplay _dice;
    private final edu.vtc.cis2271.yahtzee.YahtzeeGame _game;
    private final JTextField _message;
    private int _rerolls;

    /**
     *
     * CloseUp - the window adapter to handle closing the window
     * @author Craig A. Damon
     *
     */
    private static final class CloseUp extends WindowAdapter
    {
        /**
         * create an empty object just to do the one action
         */
        public CloseUp()
        {
            // nothing to do
        }
        /**
         * exit the program when the window closes
         * @param e the event, which is ignored
         * @see java.awt.event.WindowAdapter#windowClosing(java.awt.event.WindowEvent)
         */
        @Override
        public void windowClosing(WindowEvent e)
        {
            System.exit(0);
        }
    }

    /**
     * the main routine to start up the window and the game
     * @param args ignored
     */
    public static void main(String[] args)
    {
        edu.vtc.cis2271.yahtzee.YahtzeeGame game = new edu.vtc.cis2271.yahtzee.YahtzeeGame();
        edu.vtc.cis2271.yahtzee.Scoresheet score = game.getScoreSheet();
        YahtzeeWindow window = new YahtzeeWindow(score,game);
        window.setVisible(true);
    }
}
