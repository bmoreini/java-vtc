package edu.vtc.cis2271;

import java.util.ArrayList;
import java.util.List;

/**
 * Author - description
 * @author Bram MOreinis
 *
 */

public class Author {

    public Author(String name,int born) {
        this._name = name;
        this._books = new ArrayList<>();
        this._yearBorn = born;
        this._yearDied = STILL_ALIVE;
    }

    public String toString()
    {
        if (_yearDied == STILL_ALIVE)
            return _name + " ("+_yearBorn+" - )";
        else
            return _name + " ("+_yearBorn+" - "+_yearDied+")";
    }

    public void addBook(Book book)
    {
        _books.add(book);
    }

    public void displayBooks()
    {
        System.out.println(this);  // invokes the toString method
        int year = -1; // how does -1 end up in books array?
        for (int i = 0; i < _books.size(); i++)
        {
            Book b = _books.get(i);
            if (b.getYear() != year)
            {
                System.out.println("  "+b.getYear());
                year = b.getYear();
            }
            System.out.println("     "+b.getTitle());
        }
    }

    public static void main(String[] args)
    {
        Book b = new Book("War of the Words", 1920);
        Author a = new Author ("H.G. Wells", 1898);
        a.addBook(b);
        a.displayBooks();

    }

    private static final int STILL_ALIVE = -1000000;
    private String _name;
    private List<Book> _books;
    private int _yearBorn;
    private int _yearDied;   // STILL_ALIVE if still alive

}
