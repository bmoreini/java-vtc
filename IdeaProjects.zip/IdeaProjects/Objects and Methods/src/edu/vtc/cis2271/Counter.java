package edu.vtc.cis2271.com;

public class Counter {

    public Counter () {  // create Counter Object
        this._counter=0;
    }

    public void Click () {  // add to Counter method
        this._counter++;
    }

    public int currentCOunt () { // get Count method
        return this._counter;
    }

    public void reset() { // reset Count method
        this._counter=0;
    }

    private int _counter;  // field
    public static int maxCount;
    public static Counter highestCounter;
}

// Static = per class, not per instance.   Therefore, no instance needed.
// w1.get is calling on a particular instance, so non-static. "Instance Method".
// r.nextInt(6) is also an instance method.
// Math.random (capital letter means it's a Class). So a static method. So no "new Math".
// Constants use final.
// If static, no this.
// Refactor: select an expression of all constants, and makes them public static final name;
// If final on a non-static, you can write to it in the constructor once.
//
// Learn how to auto-generate getters and setters!




