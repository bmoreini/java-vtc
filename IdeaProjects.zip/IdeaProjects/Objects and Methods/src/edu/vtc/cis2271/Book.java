package edu.vtc.cis2271;

/*
 * C) Add an ArrayList of books to your Author class, with a method to add a book to the list.
 * The setAuthor method on book should add the Book to the list of books on the Author.
 *
 * D) Add a displayWorks method to Author which will print the Author's name and then all books written by the author,
 * one per line.  Format this list nicely, by indenting slightly.  Optionally, format this list by year of publication.
 * Assume the books are in the list in chronological order.
 */

/**
 * Book - description
 * @author Bram MOreinis
 *
 */

public class Book {

    public Book (String title, int year) {
        this._title=title;
        this._year=year;
    }

    public String getTitle () {
        return this._title;
    }

    public Author getAuthor()
    {
        return this._author;
    }

    public void setAuthor(Author author)
    {
        this._author = author;
        author.addBook(this);
    }

    public int getYear() {
        return _year;
    }

    public String toString()
    {
        return _title+" ("+_year+") by "+_author;
    }

    /* Fields / Instance Variables */
    private String _title;
    private int _year;
    private Author _author;

}
