package edu.vtc.cis2271;

/**
 A bank account has a balance that can be changed by
 deposits and withdrawals.
 */
public class BankAccount {
    /**
     * Constructs a bank account with a zero balance.
     */
    public BankAccount() {
        balance = 0;
    }


    /**
     * Constructs a bank account with a given balance.
     *
     * @param initialBalance the initial balance
     */
    public BankAccount(double initialBalance) {
        balance = initialBalance;
    }

    /**
     * Deposits money into this account.
     *
     * @param amount the amount to deposit
     */
    public void deposit(double amount) {
        balance = balance + amount;
    }

    /**
     * Makes a withdrawal from this account, or charges a penalty if
     * sufficient funds are not available.
     *
     * @param amount the amount of the withdrawal
     */
    public void withdraw(double amount) {
        final double PENALTY = 10;
        if (amount > balance) {
            balance = balance - PENALTY;
        } else {
            balance = balance - amount;
        }
    }

    /**
     * Adds interest to this account.
     *
     * @param rate the interest rate in percent
     */
    public void addInterest(double rate) {
        double amount = balance * rate / 100;
        balance = balance + amount;
    }

    /**
     * Gets the current balance of this account.
     *
     * @return the current balance
     */
    public double getBalance() {
        return balance;
    }


    private double balance;

    public static void main(String[] args) {
        BankAccount harrysAccount = new BankAccount(1000);
        harrysAccount.deposit(500); // Balance is now $1500
        harrysAccount.withdraw(2000); // Balance is now $1490
        harrysAccount.addInterest(1); // Balance is now $1490 + 14.90
        System.out.printf("%.2f%n", harrysAccount.getBalance());
        System.out.println("Expected: 1504.90");
    }

}
