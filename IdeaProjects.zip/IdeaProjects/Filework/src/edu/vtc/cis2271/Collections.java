package edu.vtc.cis2271;

public class Collections {
    public static void main(String[] args) {
        // List is a Collection. Collections has methods.  add(e) adds an element. remove (e). contains(e)?
        // size() - how big is Collection.
        // List add (i,e) add element at index. get (i,e).  set (i). remove (i).
        // These are interfaces.
        // arrayList is a kind of list.
        // List<fish> school => create a List of fish objects and call it school = new ArrayList<>();
        // <> diamond notation - same type as the type on the left.
        // List<fish> school = new ArrayList<>();
        // enhanced for loop or a for each loop
        // Collection<fish> school = newArrayList<>();
        // : = in
        // for (fish f : school) {
        // f.display();
        // if int [] data tjem
        // for (int x : data) {
        // in last part of Array chapter in book
        // new ArrayList<>(School) means make a copy of the School ArrayList - constructor
        // Two kinds of collections: Lists and Sets
        // Set is a collection that ignores duplicates
        // Always create an ArrayList for lists
        // Always create HashSets for sets -- all in java.util.
        // contains(e) you don't say s1 == s2.  That says are both strings in the same place in memory.
        // instead you want s1.equals(s2) this inherits everything that is a subclass of object
        // Object defines toString and equals
        // so contains(e) uses .equals
        // Comparable is an interface that defines compareTo
        // String implements (comparable < String)
        // All interfaces end in able (Runnable, Comparable, Printable)
        // Best way to do ordered pairs is an array of classes with two elements each


    }
}
