package edu.vtc.cis2271;

import com.sun.tools.javac.code.Lint;
// jcomponent

import javax.swing.*;
import java.awt.*;
// https://www.geeksforgeeks.org/lambda-expressions-java-8/

public class Layouts {
    Setup layout
            BorderLayout
    Box
                    Lint
    Glue

// https://docs.oracle.com/javase/tutorial/java/javaOO/lambdaexpressions.html

jtextfield
    set text
    get text
    append text

JButton
        button.addListener()
