/**
 * DrawMe.java
 * Copyright 2015, Craig A. Damon
 * all rights reserved
 */
package edu.vtc.cis2271;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JPanel;
import javax.swing.border.LineBorder;

/**
 * DrawMe - description
 * @author Craig A. Damon
 *
 */
public class DrawMe extends JPanel
{
    public DrawMe()
    {
        setMinimumSize(new Dimension(500,300));
        setPreferredSize(new Dimension(500,300));
        setBorder(new LineBorder(Color.BLUE,10));
        setBackground(Color.LIGHT_GRAY);
    }

    @Override
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        g.setColor(Color.WHITE);
        g.fillOval(225,30,50,50);
        g.fillOval(210,80,80,80);
        g.fillOval(200,160,100,100);
        g.setColor(Color.BLACK);
        g.fillOval(235,50,10,10);
        g.fillOval(255,50,10,10);
    }
}
