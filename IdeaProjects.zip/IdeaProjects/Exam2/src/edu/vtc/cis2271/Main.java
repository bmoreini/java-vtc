package edu.vtc.cis2271;

/**
 *
 * Name: Bram Moreinis
 * Exam 2
 * CIS2271 Java Programming November 15, 2018


 1.	vending machine

 Fill in the method inventoryCost() below for the partial class definition given. The method should total the cost of all remaining items.
 Presume that the class Item has a getPrice() method that returns its cost as an int.


 public class VendingMachine
 {
 // much more code would be here

 public int inventoryCost()
 {













 }

 // _items contains all the items still in the machine
 private Item[] _items;
 }

 2.	last line

 Complete the method below so that it will return the line that is alphabetically last in the text file given by its parameter. The method must handle all exceptions that might be thrown, returning null if an exception is thrown. You may presume that all needed im- ports have been provided. You can compare strings alphabetically with .compareTo().


 public String lastAlphaLine(File textFile)
 {

































 }

 3.	Exceptions
 What does the following code fragment print, given the method definitions on the next two pages?

 try {
 System.out.println(“A”); boo(1); System.out.println(“B”); boo(2); System.out.println(“C”);
 } catch (MeBadException mbe) { System.out.println(“D”); boo(3); System.out.println(“E”);
 } catch (MeWorseException mwe) { System.out.println(“F”);
 boo(4); System.out.println(“G”);
 } finally { System.out.println(“H”);
 }

 public static void boo(int i) throws MeBadException, MeWorseException
 {
 switch (i)
 {
 case 1:
 System.out.println(“a”); hoo(1); System.out.println(“b”); break;
 case 2:
 System.out.println(“c”); hoo(2); System.out.println(“d”); break;
 case 3: try {
 System.out.println(“e”); hoo (3); System.out.println(“f”);
 throw new MeWorseException();
 } catch (MeBadException mbe) { System.out.println(“g”); throw mbe;
 }
 case 4: try {
 System.out.println(“h”); hoo (4); System.out.println(“i”);
 throw new MeWorseException();
 } catch (MeBadException mbe) { System.out.println(“j”);
 throw mbe;
 }
 }
 throw new MeWorseException();
 }

 public static void hoo(int i) throws MeBadException
 {
 switch (i)
 {
 case 1:
 System.out.println(“1”); return;
 case 2:
 System.out.println(“2”); throw new MeBadException();
 case 3:
 System.out.println(“3”); return;
 }
 throw new MeBadException();
 }

 */
public class Main {

    public static void main(String[] args) {
	// write your code here
    }
}
