/**
 * Collies.java
 * Copyright 2016, Craig A. Damon
 * all rights reserved
 */
package edu.vtc.cis2271;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Collies - work on the collection worksheet
 * @author Craig A. Damon
 *
 */
public class Collies
{
	
	public Collies()
	{
		_ingredients = new HashMap<>();
	}
	
	public void addRecipe(Recipe r,Collection<Ingredient> ingredients)
	{
		for (Ingredient i : ingredients)
			{
				if (!_ingredients.containsKey(i))
					{
						// a new ingredient to me, set up the set of recipes for it
						_ingredients.put(i,new HashSet<>());
					}
				Set<Recipe> recipes = _ingredients.get(i);
				recipes.add(r);
			}
	}

	private Map<Ingredient,Set<Recipe>> _ingredients;

	public static double averageLength(Collection<String> strings)
	{
		int total = 0;
		for (String s : strings)
			{
				total += s.length();
			}
		return (double)total/strings.size();
	}
	
	public static List<String> oddFellows(List<String> strings)
	{
	   List<String> result = new ArrayList<>();	
	   for (String s : strings)
	  	 {
	  		 if (s.length() % 2 == 1)
	  			 result.add(s);
	  	 }
	   return result;
	}
		
	public static void main(String[] args)
	{
		List<String> strs = new ArrayList<>();
		strs.add("abc");
		strs.add("This string is alonger");
		strs.add("This string is alonger.");
		strs.add("abcdefgh");
		System.out.println(averageLength(strs));
		System.out.println(oddFellows(strs));
		Collies c = new Collies();
		Ingredient egg = new Ingredient("egg");
		Ingredient chocolate = new Ingredient("chocolate");
		Ingredient tomato = new Ingredient("tomato");
		Recipe fccake = new Recipe("flourless chocolate cake");
		Recipe omelet = new Recipe("omelet");
		Collection<Ingredient> ingreds1 = new ArrayList<>();
		ingreds1.add(egg);
		ingreds1.add(chocolate);
		c.addRecipe(fccake,ingreds1);
		System.out.println(c._ingredients);
		Collection<Ingredient> ingreds2 = new ArrayList<>();
		ingreds2.add(egg);
		ingreds2.add(tomato);
		c.addRecipe(omelet,ingreds2);
		System.out.println(c._ingredients);
	}
	
	
}
