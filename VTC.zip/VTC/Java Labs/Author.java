/**
 * Author.java
 * Copyright 2015, Craig A. Damon
 * all rights reserved
 */
package edu.vtc.cis2271;

import java.util.List;
import java.util.ArrayList;

/**
 * Author - an author who has (or will) written one or more books
 * @author Craig A. Damon
 *
 */
public class Author
{

	/**
	 * @param name the name of the author, never null
	 */
	public Author(String name)
	{
	  _name = name;
	  _books = new ArrayList<>();
	}

	/**
	 * use the name of the author as a human readable identifier
	 * @return the author's name
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString()
	{
		return _name;
	}
	
	/**
	 * add a book to the books written by the author
	 * @param b the book written by the author, never null
	 */
	public void addBook(Book b)
	{
		_books.add(b);
	}
	
	/**
	 * @return the name, never null
	 */
	public String getName()
	{
		return _name;
	}

	private String _name;
	private List<Book> _books;
}
