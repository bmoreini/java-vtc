/**
 * Ingredient.java
 * Copyright 2016, Craig A. Damon
 * all rights reserved
 */
package edu.vtc.cis2271;

/**
 * Ingredient - description
 * @author Craig A. Damon
 *
 */
public class Ingredient
{
  public Ingredient(String name)
  {
  	  _name = name;
  }
	
  public String toString()
  {
  	   return _name;
  }
	private String _name;
}
