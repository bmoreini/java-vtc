public class Error2
{
   public static void main(String[] args)
   {
      System.out.println("Hello, Word!"); 
         // A run-time error. The program doesn't do what it should.
   }
}
