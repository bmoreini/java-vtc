DROP TABLE Customer
CREATE TABLE Customer (Customer_Number INTEGER, Name VARCHAR(40), Address VARCHAR(40), City VARCHAR(30), State CHAR(2), Zip CHAR(10))
INSERT INTO Customer VALUES (3175, 'Sams Small Appliances', '100 Main Street', 'Anytown', 'CA', '98765')
INSERT INTO Customer VALUES (3176, 'Electronics Unlimited', '1175 Liberty Ave', 'Pleasantville', 'MI', '45066')
